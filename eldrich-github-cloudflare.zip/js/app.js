var P=[
["Pokémon","Top-Trainer-Box 30 Jahre (Deutsch)",54.99,"P","Neu seit 16.09."],
["Pokémon","Top-Trainer-Box Dunkelnacht (Deutsch)",52.99,"P","Neu"],
["Pokémon","Top-Trainer-Box Mega-Entwicklung – Erhabene Helden",null,"P","Neu"],
["Digimon","Digimon Card Game BT-26 Timeless Bonds – Display (24 Booster)",null,"D","Neu seit 04.09."],
["Digimon","Digimon Card Game BT-26 Timeless Bonds – Booster",null,"D","Neu seit 04.09."],
["Digimon","Digimon Card Game EX-13 Chivalrous XIII – Extra Booster",null,"D","Ab 02.10."],
["One Piece","One Piece Card Game OP-17 The World's Strongest Warriors – Display (24 Booster)",null,"O","Neu seit 28.08."],
["Nintendo","Nintendo Switch 2 Konsole",499.99,"N","Neue UVP seit 01.09."],
["Nintendo","Mario Kart World (Switch 2)",69.99,"N",""],
["Nintendo","The Legend of Zelda: Ocarina of Time (Switch 2)",null,"N","Ab 05.11."],
["Nintendo","Metaphor: ReFantazio (Switch 2)",null,"N","Ab 12.11."],
["PlayStation","Sony PlayStation 5 (mit Laufwerk)",649.99,"S",""],
["PlayStation","Sony PlayStation 5 Digital Edition",599.99,"S",""],
["PlayStation","Sony PlayStation 5 Pro",899.99,"S",""],
["PlayStation","Grand Theft Auto VI (PS5)",null,"S","Ab 19.11."],
["PlayStation","Warhammer 40,000: Boltgun 2 (PS5)",null,"S","Ab 14.10."],
["Xbox","Microsoft Xbox Series X (mit Laufwerk, 1 TB)",799.99,"X","Neue UVP seit 01.08."],
["Xbox","Microsoft Xbox Series S (512 GB)",499.99,"X","Neue UVP seit 01.08."],
["Xbox","Grand Theft Auto VI (Xbox Series X|S)",null,"X","Ab 19.11."],
["Xbox","Gears of War: E-Day",null,"X","Oktober 2026"],
["D&D","Forgotten Realms: Helden von Faerûn – Spielerbuch (Deutsch)",null,"D","Neu 08/2026"],
["D&D","Forgotten Realms: Adventures in Faerûn",null,"D","Neu"],
["D&D","Ravenloft: The Horrors Within (Deutsch)",null,"D","Herbst 2026"],
["D&D","Starter Set: Helden der Grenzlande (Deutsch)",null,"D","Neu seit 24.03."],
["D&D","Player's Handbook (2024)",null,"D",""],
["D&D","Nolzur's Marvelous Miniatures – bemalbar",null,"D",""],
["Warhammer","Warhammer 40,000: Codex Orks (11. Edition)",null,"W","Neu 09/2026"],
["Warhammer","Warhammer: The Old World – Battle March Armeesets",null,"W","Ab 12.09."],
["Warhammer","Horus Heresy: Legio Custodes Support Battle Group",null,"W","Ab 12.09."]
];
var F=["Alle","Pokémon","Digimon","One Piece","Nintendo","PlayStation","Xbox","D&D","Warhammer"],cur="Alle",L=['Critical hit! Im Korb.', 'You found loot!', 'Roll a nat 20. Im Korb.', 'Good choice. Choose wisely.', 'Achievement unlocked: Kaufrausch.','Der Kraken nickt zustimmend.','Ein Barde besingt deinen Einkauf.','Nur ein Mimic würde jetzt nein sagen.'],li=0,tt;
var cart=[],$=function(i){return document.getElementById(i)};
function eur(n){return n.toFixed(2).replace(".",",")+" €"}
var IC={c:'<svg viewBox="0 0 48 48"><rect x="10" y="6" width="28" height="36" rx="3"/><path d="M24 15l6 9-6 9-6-9z"/></svg>',k:'<svg viewBox="0 0 48 48"><rect x="4" y="14" width="40" height="20" rx="8"/><path d="M14 20v8M10 24h8M32 22h2M36 26h2"/></svg>',d:'<svg viewBox="0 0 48 48"><path d="M24 4l16 10v20L24 44 8 34V14z"/><path d="M24 4v40M8 14l32 20M40 14L8 34"/></svg>',b:'<svg viewBox="0 0 48 48"><path d="M8 8h26a4 4 0 014 4v28H12a4 4 0 01-4-4zM14 8v32M20 16h12"/></svg>',w:'<svg viewBox="0 0 48 48"><path d="M24 6c8 0 14 6 14 14 0 5-3 8-3 12H13c0-4-3-7-3-12 0-8 6-14 14-14zM17 38h14M19 43h10"/></svg>'};
var BR={"Pokémon":"c","Digimon":"c","One Piece":"c","Nintendo":"k","PlayStation":"k","Xbox":"k","D&D":"d","Warhammer":"w"};
function art(p){return p[5]?'<img src="'+p[5]+'" alt="'+p[1]+'" loading="lazy">':(/Handbook|Spielerbuch|Starter|Ravenloft|Adventures|Codex/.test(p[1])?IC.b:IC[BR[p[0]]])+'<em>FOTO FOLGT</em>'}
function show(){$("chips").innerHTML=F.map(function(f){return '<button class="'+(f==cur?"on":"")+'" data-f="'+f+'">'+f.toUpperCase()+'</button>'}).join("");
$("grid").innerHTML=P.map(function(p,i){return p[0]==cur||cur=="Alle"?'<article class="prod"><div class="art">'+art(p)+'</div><div class="pb"><small>'+p[0].toUpperCase()+(p[4]?' – '+p[4].toUpperCase():'')+'</small><h3>'+p[1]+'</h3><div class="pr"><b>'+(p[2]==null?"Preis folgt":eur(p[2]))+'</b>'+(p[2]==null?'<button disabled style="opacity:.4;cursor:default">BALD DA</button>':'<button data-i="'+i+'">IN DEN KORB</button>')+'</div></div></article>':""}).join("")}
$("chips").onclick=function(e){var f=e.target.getAttribute("data-f");if(f){cur=f;show()}};
document.querySelector(".cats").onclick=function(e){var a=e.target.closest("[data-f]");if(a){cur=a.getAttribute("data-f");show()}};
$("grid").onclick=function(e){var i=e.target.getAttribute("data-i");if(i!==null){cart.push(+i);draw();var t=$("toast");t.textContent=L[li++%L.length];t.classList.add("show");clearTimeout(tt);tt=setTimeout(function(){t.classList.remove("show")},1600)}};
function draw(){$("cnt").textContent=cart.length;var s=0;$("items").innerHTML=cart.length?cart.map(function(i,k){s+=P[i][2];return '<div class="it"><span>'+P[i][1]+'<br><small style="color:var(--mut)">'+eur(P[i][2])+'</small></span><button data-k="'+k+'" aria-label="Entfernen">×</button></div>'}).join(""):'<p style="color:var(--mut)">Dein Korb ist leer. It\'s dangerous to go alone – take something!</p>';$("sum").textContent=eur(s)}
$("items").onclick=function(e){var k=e.target.getAttribute("data-k");if(k!==null){cart.splice(+k,1);draw()}};
$("open").onclick=function(){$("drawer").classList.add("open")};
$("close").onclick=function(){$("drawer").classList.remove("open")};
$("checkout").onclick=function(){alert("Demo: Hier wird später dein Zahlungsanbieter (z. B. Shopify, Stripe, PayPal) angebunden.")};
var RT=function(r){return r==1?"Eine 1. Der Kraken lacht dich aus. Versuch's nochmal.":r<10?"Naja. Selbst Goblins würfeln besser.":r<15?"Solide. Ein Bier in der Taverne ist dir sicher.":r<20?"Stark! Die Bardin schreibt ein Lied über dich.":"NATÜRLICHE 20! Der Kraken ist stolz auf dich."};
$("d20").onclick=function(){var b=this,n=0,t=$("dn");b.classList.add("spin");var iv=setInterval(function(){t.textContent=1+Math.floor(Math.random()*20);if(++n>10){clearInterval(iv);var r=1+Math.floor(Math.random()*20);t.textContent=r;b.classList.remove("spin");$("dt").textContent=RT(r)}},65)};
var MS=["Der Mimic hat einen Würfel gefressen.","Aua! Er hat zurückgebissen.","Das war eine Falle. Es ist immer eine Falle.","Der Mimic rülpst. Es riecht nach Gold.","Du verlierst 1W6 Nerven."];var mi=0;
$("mimbtn").onclick=function(){var b=this,t=$("toast");b.classList.remove("bite");void b.offsetWidth;b.classList.add("bite");t.textContent=MS[mi++%MS.length];t.classList.add("show");clearTimeout(tt);tt=setTimeout(function(){t.classList.remove("show")},1800)};
var TP=["M70 260C70 210 30 190 40 140C50 90 100 100 96 60C94 30 66 24 58 44","M100 260C100 220 130 200 122 160C116 128 90 120 100 90C106 70 126 74 124 88"];
var TS='<svg viewBox="0 0 140 260">'+TP.map(function(d,i){return '<g class="sw s'+i+'"><path d="'+d+'" stroke="#8f6f3f" stroke-width="21" fill="none" stroke-linecap="round"/><path d="'+d+'" stroke="#1b120b" stroke-width="18" fill="none" stroke-linecap="round"/><path d="'+d+'" stroke="#d2ae74" stroke-width="5" stroke-dasharray="0 13" stroke-linecap="round" fill="none" opacity=".8"/></g>'}).join("")+'</svg>';
$("tl").innerHTML=TS;$("tr").innerHTML=TS;
var RM=window.matchMedia&&matchMedia("(prefers-reduced-motion:reduce)").matches;
var BAT='<svg class="bat" viewBox="0 0 60 30"><g class="wg"><path d="M30 14C24 4 12 2 0 8c6 2 8 6 9 12 5-4 10-5 14-2 3-2 5-4 7-4z"/><path d="M30 14C36 4 48 2 60 8c-6 2-8 6-9 12-5-4-10-5-14-2-3-2-5-4-7-4z"/></g><ellipse cx="30" cy="16" rx="3" ry="6"/></svg>';
var hero=document.querySelector(".hero");
function bat(d){if(RM||document.hidden||hero.querySelectorAll(".bat").length>5)return;hero.insertAdjacentHTML("beforeend",BAT);var e=hero.lastElementChild;e.style.top=(20+Math.random()*230)+"px";e.style.animationDelay=d+"s";e.style.animationDuration=(7+Math.random()*4)+"s";e.addEventListener("animationend",function(ev){if(ev.animationName=="fly")e.remove()})}
for(var q=0;q<4;q++)bat(q*.9+.5);setInterval(function(){bat(0)},6000);
var EM=$("em");if(!RM){for(var z=0;z<26;z++){var s=2+Math.random()*3.5,ei=document.createElement("i");ei.style.cssText="left:"+Math.random()*100+"%;width:"+s+"px;height:"+s+"px;--dx:"+(Math.random()*80-40)+"px;animation-duration:"+(9+Math.random()*12)+"s;animation-delay:-"+Math.random()*18+"s";EM.appendChild(ei)}}
var eye=document.querySelector(".eye"),pup=$("pup");
document.addEventListener("pointermove",function(e){var r=eye.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height*.6),m=Math.max(1,Math.hypot(dx,dy)),k=Math.min(1,m/200);pup.setAttribute("transform","translate("+(dx/m*14*k).toFixed(1)+" "+(dy/m*7*k).toFixed(1)+")")});
show();draw();
